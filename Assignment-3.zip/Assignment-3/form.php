<?php
if(isset($_POST['submit'])){
    $Name=$_POST['Name'];
    $email=$_POST['email'];
    // $Mobile =$_POST['Mobile'];
    // $Services=$_POST['Services'];
    $Rating=$_POST['Rating'];
    $Message=$_POST['Message'];

    $servername="localhost";
    $username="root";
    $password="";
    $dbname="feedback";
    $conn=mysqli_connect($servername,$username,$password,$dbname);
   $sql="INSERT INTO feedback(Name,email,Mobile,Services,Rating,Message) values('$Name,$email,$Rating,$Message)";
   mysqli_query($conn,$sql);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
    font-size: 16px;
    background: #f9f9f9;
    font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
}

h2 {
    text-align: center;
    text-decoration: underline;
}
form {
    background-image: url("https://th.bing.com/th/id/OIP.A0U5ouEgAox7Yjk6o17MjQAAAA?pid=ImgDet&rs=1");
    width: 500px;
    padding: 15px 40px 40px;
    border: 1px solid #ccc;
    margin: 50px auto 0;
    border-radius: 5px;
    
}
label {
    display: block;
    margin-bottom: 5px
}
label i {
    color: #999;
    font-size: 80%;
}
input, select {
    border: 1px solid #ccc;
    padding: 10px;
    display: block;
    width: 100%;
    box-sizing: border-box;
    border-radius: 2px;
}
.row {
    padding-bottom: 10px;
}
.form-inline {
    border: 1px solid #ccc;
    padding: 8px 10px 4px;
    border-radius: 2px;
}
.form-inline label, .form-inline input {
    display: inline-block;
    width: auto;
    padding-right: 15px;
}
.error {
    color: red;
    font-size: 90%;
}
input[type="submit"] {
    font-size: 110%;
    font-weight: 100;
    background: #006dcc;
    border-color: #016BC1;
    box-shadow: 0 3px 0 #0165b6;
    color: #fff;
    margin-top: 10px;
    cursor: pointer;
}
input[type="submit"]:hover {
    background: #0165b6;
}
</style>
</head>
<body class="feedform">
    <form  name="contactForm" action="#"   method="post">
        <h2>Feedback Form</h2>
        <div class="row"></div>
        <label>Full name:</label>
        <input type="text" name="Name">
      
        </div>
        <div class="row">

            <label>email id:</label>
            <input type="email" name="email">
       
        </div>
       
        <div class="row">
            
            <label>Rate us</label>
            <div class="form-inline" >
             

            <label><input type="radio" name="Rating" value="1">1</label>
            <label><input type="radio" name="Rating" value="2">2</label>
            <label><input type="radio" name="Rating" value="3">3</label>
            <label><input type="radio" name="Rating" value="4">4</label>
            <label><input type="radio" name="Rating" value="5">5</label>
           
         

                
            </div>
        </div>
            <div class="row">
               <label>Type your Message </label>
                <div class="form-inline">
               <textarea name="Message" placeholder="Enter Your Feedback " style="width:463px; height:90px;"></textarea>
            
                </div>
            </div>
            <div class="row">
                <input type="submit" value="submit" name="submit">
            </div>
    </form>
</body>

</html>